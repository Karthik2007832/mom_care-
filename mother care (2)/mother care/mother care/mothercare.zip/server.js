// ============================================================================
//   Mom Care Dashboard - Node.js Backend Server
//   DUAL MODE: Accepts data from ESP32 via WiFi POST *and* USB Serial
//   simultaneously — whichever sends data first wins, both work together.
//
//   MODE env var:
//     auto     (default) → tries Serial + also listens for WiFi POST
//     wifi     → WiFi POST only (no serial)
//     serial   → Serial only (no WiFi POST)
//     simulate → Realistic fake data
// ============================================================================

require('dotenv').config();

const express = require('express');
const http    = require('http');
const { Server } = require('socket.io');
const path    = require('path');
const os      = require('os');
const Groq    = require('groq-sdk');

let groq = null; // Lazy-initialized when first /api/chat request arrives

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });

app.use(express.json());
app.use(express.text());
app.use(express.static(path.join(__dirname, 'public')));

// ── Configuration ──────────────────────────────────────────────────────────
const MODE        = (process.env.MODE || 'auto').toLowerCase();
const SERIAL_PORT = process.env.SERIAL_PORT || 'COM7';
const BAUD_RATE   = parseInt(process.env.BAUD_RATE  || '115200');
const SERVER_PORT = parseInt(process.env.PORT        || '3000');

// ── Fall Alert Threshold ───────────────────────────────────────────────────
const FALL_G_THRESHOLD = 3.5; // Matched to Arduino sketch threshold

// ── History Buffer ─────────────────────────────────────────────────────────
const MAX_HISTORY = 60;
const history = {
  ecg: [], bpm: [], piezo: [], kicks: [], motion: [], temp: [], timestamps: [],
};
let latestData = {
  ecg: 0, bpm: 0, piezo: 0, kicks: 0, motion: 0, temp: 0,
  fallAlert: false, timestamp: Date.now()
};

// Track connection state
let esp32Ip       = null;
let serialActive  = false;
let dataSource    = 'none';   // 'serial' | 'wifi' | 'simulate'

// ── Get local WiFi IP for display ─────────────────────────────────────────
function getLocalIp() {
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    if (!name.toLowerCase().includes('wi') && !name.toLowerCase().includes('wlan') && !name.toLowerCase().includes('wireless')) continue;
    for (const iface of ifaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  // Fallback: any non-internal IPv4
  for (const ifaces2 of Object.values(os.networkInterfaces())) {
    for (const iface of ifaces2) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  return 'localhost';
}

// ── BPM noise rejection ────────────────────────────────────────────────────
// Maternal heart rate is physiologically 40–130 BPM.
// Values outside this range are treated as sensor glitches.
const BPM_VALID_MIN = 40;
const BPM_VALID_MAX = 130;

// ── Parse CSV line from Arduino ────────────────────────────────────────────
function parseLine(line) {
  try {
    const trimmed = line.trim();
    if (!trimmed.startsWith('ECG:')) return null;
    const parts = {};
    trimmed.split(',').forEach(segment => {
      const colonIdx = segment.indexOf(':');
      if (colonIdx > 0) {
        parts[segment.substring(0, colonIdx).trim()] = parseFloat(segment.substring(colonIdx + 1).trim());
      }
    });
    if (isNaN(parts['ECG'])) return null;

    // Clamp BPM: discard readings outside physiological range (noise filter)
    let rawBpm = parts['Maternal_BPM'] ?? 0;
    const cleanBpm = (rawBpm > BPM_VALID_MIN && rawBpm <= BPM_VALID_MAX) ? rawBpm : 0;

    return {
      ecg:        parts['ECG']            ?? 0,
      bpm:        cleanBpm,
      piezo:      parts['Piezo_Force']    ?? 0,
      kicks:      parts['Kicks_Total']    ?? 0,
      motion:     parts['Motion_Total_G'] ?? 0,
      temp:       parts['Temp_C']         ?? 0,
      fallAlert:  parts['Fall_Alert'] === 1,
      sosCall:    parts['SOS_Call'] === 1,
      pressCount: parts['Press_Count']    ?? 0,
      mpuOK:      parts['MPU_OK'] !== 0,
      timestamp:  Date.now()
    };
  } catch { return null; }
}

function appendHistory(data) {
  ['ecg','bpm','piezo','kicks','motion','temp'].forEach(k => {
    history[k].push(data[k]);
    if (history[k].length > MAX_HISTORY) history[k].shift();
  });
  history.timestamps.push(data.timestamp);
  if (history.timestamps.length > MAX_HISTORY) history.timestamps.shift();
}

function broadcast(data, source) {
  latestData = data;
  dataSource = source;
  appendHistory(data);
  io.emit('sensorData', { latest: data, history });
}

// ============================================================================
//   WIFI ENDPOINT — ESP32 POSTs here
// ============================================================================
app.post('/api/data', (req, res) => {
  const senderIp = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').replace('::ffff:', '');

  if (senderIp && senderIp !== esp32Ip) {
    esp32Ip = senderIp;
    console.log(`✅ ESP32 connected via WiFi from ${esp32Ip}`);
    io.emit('portStatus', { status: 'wifi_connected', esp32Ip, message: `ESP32 connected via WiFi (${esp32Ip})` });
  }

  const body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
  const data = parseLine(body);
  if (data) {
    broadcast(data, 'wifi');
    res.json({ ok: true });
  } else {
    res.status(400).json({ ok: false, error: 'Could not parse sensor line' });
  }
});

// ============================================================================
//   SERIAL MODE — USB cable from ESP32
// ============================================================================
function trySerial() {
  if (MODE === 'wifi' || MODE === 'simulate') return;

  let SerialPort, ReadlineParser;
  try {
    ({ SerialPort }     = require('serialport'));
    ({ ReadlineParser } = require('@serialport/parser-readline'));
  } catch {
    console.log('ℹ️  serialport not available — skipping serial mode');
    return;
  }

  let retryTimer = null;

  function connectSerial() {
    if (serialActive) return;
    console.log(`🔌 Trying Serial port ${SERIAL_PORT} at ${BAUD_RATE} baud...`);
    io.emit('portStatus', { status: 'connecting', port: SERIAL_PORT });

    let port;
    try {
      port = new SerialPort({ path: SERIAL_PORT, baudRate: BAUD_RATE, autoOpen: false });
    } catch (err) {
      scheduleRetry();
      return;
    }

    port.open(err => {
      if (err) {
        console.log(`⚠️  Serial ${SERIAL_PORT} unavailable: ${err.message}`);
        io.emit('portStatus', { status: 'error', message: `Serial not available: ${err.message}` });
        scheduleRetry();
        return;
      }
      serialActive = true;
      console.log(`✅ Serial ${SERIAL_PORT} open — live USB data streaming`);
      io.emit('portStatus', { status: 'connected', port: SERIAL_PORT });

      const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));
      parser.on('data', line => {
        // ── RAW DEBUG: print every line from ESP32 ──
        const trimmed = line.trim();
        if (trimmed.length > 0) {
          console.log('[RAW]', trimmed.substring(0, 120));
        }
        const data = parseLine(line);
        if (data) broadcast(data, 'serial');
      });

      port.on('close', () => {
        serialActive = false;
        console.log('⚠️  Serial port closed. Retrying in 3s...');
        io.emit('portStatus', { status: 'disconnected' });
        scheduleRetry();
      });

      port.on('error', () => {
        serialActive = false;
        scheduleRetry();
      });
    });
  }

  function scheduleRetry() {
    if (retryTimer) clearTimeout(retryTimer);
    retryTimer = setTimeout(connectSerial, 3000);
  }

  connectSerial();
}

// ============================================================================
//   SIMULATION MODE
// ============================================================================
let simTime = 0, simKicks = 0, simBpm = 72;

function simulateData() {
  simTime += 0.05;
  simBpm = 72 + Math.sin(simTime * 0.1) * 8 + (Math.random() - 0.5) * 2;
  const phase = (simTime % (60 / simBpm)) / (60 / simBpm);
  let ecg = 2048;
  if (phase > 0.45 && phase < 0.55) ecg += Math.sin((phase - 0.45) / 0.1 * Math.PI) * 700;
  const doKick = Math.random() < 0.005;
  if (doKick) simKicks++;
  const piezo  = doKick ? 200 + Math.random() * 300 : Math.random() * 30;
  const doBump = Math.random() < 0.002;
  const motion = doBump ? 2.6 + Math.random() * 0.5 : 0.95 + (Math.random() - 0.5) * 0.1;
  const temp   = 36.5 + Math.sin(simTime * 0.02) * 0.5 + (Math.random() - 0.5) * 0.1;
  return {
    ecg: Math.round(ecg), bpm: parseFloat(simBpm.toFixed(1)),
    piezo: parseFloat(piezo.toFixed(1)), kicks: simKicks,
    motion: parseFloat(motion.toFixed(3)), temp: parseFloat(temp.toFixed(2)),
    fallAlert: motion > FALL_G_THRESHOLD, mpuOK: true, timestamp: Date.now()
  };
}

// ── REST endpoints ─────────────────────────────────────────────────────────
app.get('/api/ports', async (req, res) => {
  try {
    const { SerialPort } = require('serialport');
    res.json(await SerialPort.list());
  } catch { res.json([]); }
});

app.get('/api/history', (req, res) => res.json({ latest: latestData, history }));

app.get('/api/status', (req, res) => {
  res.json({ mode: MODE, dataSource, serialActive, esp32Ip, serverIp: getLocalIp() });
});

// ── GROQ AI CHAT ENDPOINT ─────────────────────────────────────────────────
app.post('/api/chat', async (req, res) => {
  if (!process.env.GROQ_API_KEY) {
    return res.status(503).json({ error: 'Groq API key not configured. Add GROQ_API_KEY to your .env file.' });
  }

  // Lazy-initialize or refresh Groq client on request
  groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

  const { message, vitals } = req.body;
  if (!message) return res.status(400).json({ error: 'No message provided.' });

  // Build a rich system prompt with live sensor data
  const vitalsContext = vitals ? `
Current live sensor readings from the MomCare monitoring system:
- Maternal Heart Rate (BPM): ${vitals.bpm > 0 ? vitals.bpm.toFixed(1) + ' BPM' : 'No reading'}
- Body Temperature: ${vitals.temp > 30 ? vitals.temp.toFixed(2) + ' °C' : 'No reading'}
- Motion (G-Force): ${vitals.motion !== undefined ? vitals.motion.toFixed(3) + ' G' : 'N/A'}
- Fetal Kick Count: ${vitals.kicks ?? 0}
- Piezo Impact Force: ${vitals.piezo !== undefined ? vitals.piezo.toFixed(1) : 'N/A'}
- Fall Alert: ${vitals.fallAlert ? 'YES — FALL DETECTED' : 'No'}
- MPU6050 Sensor: ${vitals.mpuOK === false ? 'Offline' : 'Online'}
` : 'No live sensor data is currently available.';

  const systemPrompt = `You are MomCare Clinical AI, an expert, compassionate obstetric & maternal health medical assistant integrated into a real-time IoT health monitoring system.

${vitalsContext}

Your clinical guidance principles:
1. Provide professional, evidence-based, compassionate, and accurate answers regarding maternal health, pregnancy stages, fetal development, nutrition, hydration, and vitals.
2. Directly refer to the patient's live IoT sensor readings above when answering questions about their current physical status.
3. If vitals show abnormalities (e.g., Heart Rate > 120 BPM, Fever > 37.5°C, or Sudden Fall Alert), gently warn the mother and recommend notifying their healthcare provider or caregiver.
4. Maintain a reassuring, supportive, and respectful tone at all times.
5. Provide concise, well-structured, easy-to-read answers with bullet points when applicable.`;

  try {
    let completion;
    try {
      completion = await groq.chat.completions.create({
        model: 'openai/gpt-oss-120b',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user',   content: message }
        ],
        max_tokens: 800,
        temperature: 0.6,
      });
    } catch (modelErr) {
      console.warn('Fallback to openai/gpt-oss-20b:', modelErr.message);
      completion = await groq.chat.completions.create({
        model: 'openai/gpt-oss-20b',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user',   content: message }
        ],
        max_tokens: 600,
        temperature: 0.6,
      });
    }

    const reply = completion.choices[0]?.message?.content?.trim() || 'Sorry, I could not generate a response.';
    res.json({ reply });
  } catch (err) {
    console.error('Groq API error:', err.message);
    res.status(500).json({ error: 'AI service error: ' + err.message });
  }
});

// ── WHATSAPP ALERT ENDPOINT ───────────────────────────────────────────────
const sentAlerts = new Set();

app.post('/api/alert', async (req, res) => {
  const { alertMessage, timestamp, motherName, recipientNumber } = req.body;
  
  if (!alertMessage) return res.status(400).json({ error: 'No alertMessage provided.' });
  
  // Deduplication check
  const alertId = `${alertMessage}_${timestamp}`;
  if (sentAlerts.has(alertId)) {
    return res.json({ success: true, duplicate: true, status: 'Already notified' });
  }
  sentAlerts.add(alertId);
  
  // Prevent memory leak
  if (sentAlerts.size > 1000) {
    const firstItem = sentAlerts.values().next().value;
    sentAlerts.delete(firstItem);
  }

  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const finalRecipient = recipientNumber || process.env.WHATSAPP_RECIPIENT_NUMBER;
  const finalMotherName = motherName || 'Mom';
  
  const timeString = timestamp ? new Date(timestamp).toLocaleTimeString('en-IN') : new Date().toLocaleTimeString('en-IN');
  
  const textBody = `🚨 MOMCARE 360 ALERT\n\nMother: ${finalMotherName}\n\nAlert:\n${alertMessage}\n\nTime:\n${timeString}\n\nPlease check the mother and take appropriate action if required.\n\nThis is an AI-assisted monitoring alert and not a medical diagnosis.`;

  if (token && phoneId && finalRecipient) {
    // Real API call
    try {
      const response = await fetch(`https://graph.facebook.com/v17.0/${phoneId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: finalRecipient,
          type: 'text',
          text: { body: textBody }
        })
      });
      
      const result = await response.json();
      if (response.ok) {
        return res.json({ success: true, status: 'SENT', recipient: finalRecipient });
      } else {
        console.error('WhatsApp API Error:', result);
        return res.status(500).json({ success: false, error: result.error?.message || 'API Error' });
      }
    } catch (err) {
      console.error('WhatsApp API Request Failed:', err);
      return res.status(500).json({ success: false, error: 'Network Error' });
    }
  } else {
    // No credentials, silently ignore instead of mock logging
    return res.json({ success: true, status: 'SKIPPED_NO_CREDENTIALS', recipient: finalRecipient });
  }
});

// ── WebSocket ──────────────────────────────────────────────────────────────
io.on('connection', socket => {
  const clientIp = socket.handshake.address.replace('::ffff:', '');
  console.log(`🖥️  Browser connected: ${clientIp} (${socket.id})`);
  socket.emit('sensorData', { latest: latestData, history });

  // Send current connection state to new browser client
  if (MODE === 'simulate') {
    socket.emit('portStatus', { status: 'simulating', message: 'Running in simulation mode' });
  } else if (esp32Ip) {
    socket.emit('portStatus', { status: 'wifi_connected', esp32Ip, message: `ESP32 connected via WiFi (${esp32Ip})` });
  } else if (serialActive) {
    socket.emit('portStatus', { status: 'connected', port: SERIAL_PORT });
  } else {
    socket.emit('portStatus', {
      status: 'wifi_waiting',
      message: `Waiting for ESP32... (flash sketch & connect to WiFi, or plug USB to ${SERIAL_PORT})`
    });
  }

  socket.on('disconnect', () => console.log(`❌ Browser disconnected: ${socket.id}`));
});

// ── Start server ───────────────────────────────────────────────────────────
const localIp = getLocalIp();

server.listen(SERVER_PORT, '0.0.0.0', () => {
  console.log('\n╔══════════════════════════════════════════════════════════╗');
  console.log(`║  🌐 MomCare Dashboard                                    ║`);
  console.log(`║     Local:   http://localhost:${SERVER_PORT}                     ║`);
  console.log(`║     Network: http://${localIp}:${SERVER_PORT}                ║`);
  console.log(`║  📡 Mode: ${MODE.toUpperCase().padEnd(47)}║`);
  console.log('╠══════════════════════════════════════════════════════════╣');

  if (MODE === 'simulate') {
    console.log('║  🔄 Simulation mode — generating fake sensor data        ║');
    console.log('╚══════════════════════════════════════════════════════════╝\n');
    io.emit('portStatus', { status: 'simulating', message: 'Running in simulation mode' });
    setInterval(() => broadcast(simulateData(), 'simulate'), 50);
  } else if (MODE === 'wifi') {
    console.log(`║  📡 WiFi only — ESP32 POST to:                           ║`);
    console.log(`║     http://${localIp}:${SERVER_PORT}/api/data             ║`);
    console.log('╚══════════════════════════════════════════════════════════╝\n');
    io.emit('portStatus', { status: 'wifi_waiting', message: 'WiFi mode — waiting for ESP32...' });
  } else {
    // AUTO or SERIAL: try serial and ALSO accept WiFi POSTs
    console.log(`║  🔌 Serial: ${SERIAL_PORT} at ${BAUD_RATE} baud                     ║`);
    console.log(`║  📡 WiFi POST: http://${localIp}:${SERVER_PORT}/api/data  ║`);
    console.log('║  (whichever connects first will stream live data)        ║');
    console.log('╚══════════════════════════════════════════════════════════╝\n');
    trySerial();
  }
});
