/* ══════════════════════════════════════════════════════════════════════════
   Mom Care Dashboard — app.js
   Real-time sensor visualization with Chart.js-like Canvas rendering
   ══════════════════════════════════════════════════════════════════════════ */

'use strict';

// ── Constants ──────────────────────────────────────────────────────────────
const BPM_NORMAL_MIN  = 60;
const BPM_NORMAL_MAX  = 100;
const TEMP_NORMAL_MIN = 36.1;
const TEMP_NORMAL_MAX = 37.5;
const TEMP_FEVER      = 37.5;
const MOTION_FALL     = 2.5;
const MAX_ECG_POINTS  = 200; // ECG scroll buffer

// ── State ──────────────────────────────────────────────────────────────────
let dataCount     = 0;
let startTime     = Date.now();
let lastKickCount = 0;   // last raw value that triggered a new-kick event
let rawKickCount  = 0;   // always the latest raw sensor value
let kickOffset    = 0;   // subtracted from raw sensor count for display
let alertCount    = 0;
const MAX_ALERTS  = 50;
let lastValidBpm  = null;  // holds last good BPM reading so display never blanks
let isBleConnected = false;

// ECG ring buffer
const ecgBuffer = new Array(MAX_ECG_POINTS).fill(2048);
let ecgWriteHead = 0;

// ── DOM References ─────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const valBpm     = $('valBpm');
const valTemp    = $('valTemp');
const valKicks   = $('valKicks');
const valMotion  = $('valMotion');
const valPiezo   = $('valPiezo');
const valFall    = $('valFall');
const statusBpm  = $('statusBpm');
const statusTemp = $('statusTemp');
const statusKicks= $('statusKicks');
const statusMotion=$('statusMotion');
const statusPiezo= $('statusPiezo');
const statusFall = $('statusFall');
const fallIcon   = $('fallIcon');       // div badge inside fall card
const cardFall   = $('cardFall');
const tempBar    = $('tempBar');
const piezoBar   = $('piezoBar');
const alertLog   = $('alertLog');
const ecgBpmDisplay = $('ecgBpmDisplay');
const connectionStatus = $('connectionStatus');
const statusText = $('statusText');
const fallOverlay = $('fallAlertOverlay');
const sysMpuStatus = $('sysMpuStatus'); // Live MPU6050 online/offline status
const sysConnMode  = $('sysConnMode');  // Connection mode (WiFi / Serial / Simulation)
const sysEsp32Ip   = $('sysEsp32Ip');  // ESP32 IP address in WiFi mode

// ── Canvas Contexts ────────────────────────────────────────────────────────
const ecgCanvas     = $('ecgCanvas');
const ecgCtx        = ecgCanvas.getContext('2d');
const bpmCanvas     = $('bpmChart');
const bpmCtx        = bpmCanvas.getContext('2d');
const tempCanvas    = $('tempChart');
const tempCtx       = tempCanvas.getContext('2d');
const motionCanvas  = $('motionChart');
const motionCtx     = motionCanvas.getContext('2d');
const kickCanvas    = $('kickChart');
const kickCtx       = kickCanvas.getContext('2d');
const motionGauge   = $('motionGauge');
const gaugeCtx      = motionGauge.getContext('2d');

// ── CLOCK ──────────────────────────────────────────────────────────────────
function updateClock() {
  const headerTimeEl = $('headerTime');
  if (headerTimeEl) headerTimeEl.textContent = new Date().toLocaleTimeString('en-IN', { hour12: false });
  const uptimeEl = $('sysUptime');
  if (uptimeEl) uptimeEl.textContent = formatDuration(Date.now() - startTime);
}
setInterval(updateClock, 1000);
updateClock();

function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

// ── CONNECTION STATUS ───────────────────────────────────────────────────────
function setConnected(state) {
  connectionStatus.className = 'status-pill ' + state;
  if (state === 'connected') statusText.textContent = 'Connected';
  else if (state === 'error') statusText.textContent = 'Disconnected';
  else statusText.textContent = 'Connecting...';
}

// ── SOCKET.IO CONNECTION ────────────────────────────────────────────────────
const socket = io();

socket.on('connect', () => setConnected('connected'));
socket.on('disconnect', () => setConnected('error'));
socket.on('connect_error', () => setConnected('error'));

// Handle serial/wifi port status messages — update live dot only, no alert log
socket.on('portStatus', ({ status, esp32Ip, port }) => {
  if (isBleConnected) return; // Ignore backend status if we have a direct BLE connection
  const liveDot = document.querySelector('#liveIndicator .live-dot');
  const dotColors = {
    connected:      '#4ade80',
    wifi_connected: '#4ade80',
    simulating:     '#a78bfa',
    wifi_waiting:   '#38bdf8',
    connecting:     '#38bdf8',
    disconnected:   '#fbbf24',
    error:          '#fbbf24',
  };
  const color = dotColors[status] || '#38bdf8';
  if (liveDot) { liveDot.style.background = color; liveDot.style.boxShadow = `0 0 8px ${color}`; }

  // Update sys-info fields if they exist
  if (sysConnMode) {
    if (status === 'connected')      sysConnMode.textContent = `Serial (${port})`;
    if (status === 'wifi_connected') sysConnMode.textContent = 'WiFi';
    if (status === 'simulating')     sysConnMode.textContent = 'Simulation';
    if (status === 'wifi_waiting')   sysConnMode.textContent = 'WiFi (waiting)';
  }
  if (sysEsp32Ip && esp32Ip) sysEsp32Ip.textContent = esp32Ip;
});


socket.on('sensorData', ({ latest, history }) => {
  // STRICT BLE MODE: Only update dashboard if Bluetooth is actively connected
  if (!isBleConnected) return;

  dataCount++;
  const dpEl = $('sysDataPoints');
  if (dpEl) dpEl.textContent = dataCount.toLocaleString();
  updateDashboard(latest, history);
});

// ── MAIN UPDATE FUNCTION ────────────────────────────────────────────────────
function updateDashboard(data, history) {
  // Guard: Never display or render data unless Bluetooth is connected
  if (!isBleConnected) return;

  updateBpm(data.bpm);
  updateTemp(data.temp);
  updateKicks(data.kicks);
  updateMotion(data.motion, data.mpuOK);
  updatePiezo(data.piezo);
  updateFall(data.fallAlert, data.motion);  // Use explicit Arduino flag
  updateSos(data.sosCall);                  // Emergency SOS 3-press call trigger
  updateEcg(data.ecg);

  // Update charts (throttled to every 3 frames for performance)
  if (dataCount % 3 === 0) {
    drawLineChart(bpmCtx, bpmCanvas, history.bpm, {
      color: '#E11D48', fill: 'rgba(225,29,72,0.15)',
      label: 'BPM', min: 40, max: 120,
      referenceLines: [{ y: BPM_NORMAL_MIN, color: 'rgba(74,222,128,0.4)' },
                       { y: BPM_NORMAL_MAX, color: 'rgba(225,29,72,0.4)' }]
    });
    drawLineChart(tempCtx, tempCanvas, history.temp, {
      color: '#F59E0B', fill: 'rgba(245,158,11,0.15)',
      label: '°C', min: 35, max: 40
    });
    drawLineChart(motionCtx, motionCanvas, history.motion, {
      color: '#06B6D4', fill: 'rgba(6,182,212,0.15)',
      label: 'G', min: 0, max: 4,
      referenceLines: [{ y: MOTION_FALL, color: 'rgba(225,29,72,0.5)' }]
    });
    drawBarChart(kickCtx, kickCanvas, history.piezo, {
      color: '#10B981', label: 'Force'
    });

    // Show last valid BPM in ECG header — never blank after first reading
    if (lastValidBpm !== null) {
      ecgBpmDisplay.textContent = `${lastValidBpm.toFixed(0)} BPM`;
    }
  }

  drawMotionGauge(gaugeCtx, motionGauge, data.motion);
}

// ── KPI UPDATERS ────────────────────────────────────────────────────────────
function flashValue(el) {
  el.classList.remove('val-update');
  void el.offsetWidth;
  el.classList.add('val-update');
}

// Valid physiological BPM range for maternal heart rate
const BPM_VALID_MIN = 40;
const BPM_VALID_MAX = 130;

function updateBpm(bpm) {
  const isValid = bpm > BPM_VALID_MIN && bpm <= BPM_VALID_MAX;

  if (isValid) {
    lastValidBpm = bpm;
    valBpm.textContent = bpm.toFixed(0);
    flashValue(valBpm);
    statusBpm.textContent = 'Normal';
    statusBpm.style.color = '#4ade80';
  } else if (lastValidBpm !== null) {
    // Keep last known good reading
    valBpm.textContent = lastValidBpm.toFixed(0);
    statusBpm.textContent = 'Last reading';
    statusBpm.style.color = '#4ade80';
  } else if (bpm > 0) {
    // Show raw value even if out of range — helps diagnose sensor
    valBpm.textContent = bpm.toFixed(0);
    statusBpm.textContent = 'Check leads';
    statusBpm.style.color = '#fbbf24';
  } else {
    valBpm.textContent = '0';
    statusBpm.textContent = '0 BPM';
    statusBpm.style.color = '#8ba3c7';
  }

  // Pulse ring animation
  const ring = $('pulseRingBpm');
  ring.classList.remove('pulse');
  void ring.offsetWidth;
  ring.classList.add('pulse');

  // Show ECG BPM in header
  if (lastValidBpm !== null) {
    ecgBpmDisplay.textContent = `${lastValidBpm.toFixed(0)} BPM`;
  } else if (bpm > 0) {
    ecgBpmDisplay.textContent = `${bpm.toFixed(0)} BPM (raw)`;
  } else {
    ecgBpmDisplay.textContent = '0 BPM';
  }

  // BP / BPM Alert
  if (bpm > 140) {
    addAlert(`CRITICAL: High BPM / BP detected (${bpm.toFixed(0)})`, 'critical');
  }
}

function updateTemp(temp) {
  // Values below 30 are sensor noise — display 0.0 gracefully before connection.
  if (temp < 30 || isNaN(temp)) {
    valTemp.textContent = '0.0';
    statusTemp.textContent = '0.0 °C';
    tempBar.style.width = '0%';
    return;
  }
  valTemp.textContent = temp.toFixed(1);
  flashValue(valTemp);

  // Progress bar (35–40°C range)
  const pct = Math.min(100, Math.max(0, ((temp - 35) / 5) * 100));
  tempBar.style.width = pct + '%';

  if (temp > 39) {
    statusTemp.textContent = 'High Temp Alert';
    statusTemp.style.color = '#ff2d55';
    addAlert(`WARNING: High Body Temperature detected (${temp.toFixed(1)}°C)`, 'critical');
  } else {
    statusTemp.textContent = 'Monitoring';
    statusTemp.style.color = '#4ade80';
  }
}


function updateKicks(kicks) {
  rawKickCount = kicks;  // still track raw for future use
  const displayKicks = Math.max(0, kicks - kickOffset);
  valKicks.textContent = displayKicks.toString();
  
  if (kicks > lastKickCount) {
    statusKicks.textContent = 'Kick detected!';
    statusKicks.style.color = '#a78bfa';
    // Flash effect
    valKicks.classList.remove('val-update');
    void valKicks.offsetWidth;
    valKicks.classList.add('val-update');
    lastKickCount = kicks;
  } else {
    statusKicks.textContent = 'Monitoring...';
    statusKicks.style.color = '#8ba3c7';
  }
}


// Reset kick counter to zero (offsets from current raw Arduino total)
window.resetKicks = function() {
  kickOffset    = rawKickCount;   // offset = current sensor value
  lastKickCount = rawKickCount;   // so next new kick is detected correctly
  valKicks.textContent = '0';
  statusKicks.textContent = 'Monitoring...';
};

function updateMotion(g, mpuOK) {
  // Update System Info MPU6050 live status (only if element exists)
  if (sysMpuStatus) {
    if (mpuOK === false) {
      sysMpuStatus.textContent = 'Offline';
      sysMpuStatus.style.color = '#fbbf24';
    } else {
      sysMpuStatus.textContent = 'Online (SDA=20/SCL=21)';
      sysMpuStatus.style.color = '#4ade80';
    }
  }

  // Show zero when MPU6050 is not active
  if (mpuOK === false) {
    valMotion.textContent = '0.00';
    statusMotion.textContent = '0.00 G';
    statusMotion.style.color = '#fbbf24';
    return;
  }

  valMotion.textContent = (g ?? 0).toFixed(2);
  flashValue(valMotion);

  if (g > 50) {
    statusMotion.textContent = 'CRITICAL G-FORCE';
    statusMotion.style.color = '#ff2d55';
    addAlert(`CRITICAL: Motion G-Force exceeded 50G (${g.toFixed(2)}G)`, 'critical');
  } else if (g > MOTION_FALL) {
    statusMotion.textContent = 'FALL THRESHOLD';
    statusMotion.style.color = '#ff2d55';
  } else if (g > 1.5) {
    statusMotion.textContent = 'High motion';
    statusMotion.style.color = '#fbbf24';
  } else if (g < 0.90) {
    statusMotion.textContent = 'LOW G-FORCE';
    statusMotion.style.color = '#fbbf24';
    addAlert(`WARNING: Low G-Force detected (${g.toFixed(2)}G)`, 'warning');
  } else {
    statusMotion.textContent = 'Stable';
    statusMotion.style.color = '#4ade80';
  }
}

let lastPiezoActivityTime = Date.now();
setInterval(() => {
  if (Date.now() - lastPiezoActivityTime > 5 * 60 * 60 * 1000) {
    addAlert("WARNING: No fetal movement (piezo activity) detected for 5 hours.", "critical");
    lastPiezoActivityTime = Date.now(); // Reset to avoid spamming every minute
  }
}, 60000);

function updatePiezo(force) {
  if (force > 10) {
    lastPiezoActivityTime = Date.now();
  }
  valPiezo.textContent = force.toFixed(0);
  const barWidth = Math.min(100, (force / 500) * 100);
  piezoBar.style.width = barWidth + '%';
  piezoBar.style.opacity = force > 20 ? '1' : '0.3';
  statusPiezo.textContent = '';
}

let fallActive = false;
let fallCooldown = 0;

function updateFall(isFall, g) {
  if (isFall && !fallActive) {
    fallActive = true;
    valFall.textContent = 'FALL';
    valFall.style.color = '#ff2d55';
    if (fallIcon) fallIcon.textContent = '!';
    statusFall.textContent = `Impact: ${(g ?? 0).toFixed(2)}G detected!`;
    cardFall.classList.add('danger-mode');
    cardFall.style.borderTopColor = 'var(--danger)';
    fallOverlay.classList.remove('hidden');
    addAlert('FALL DETECTED — Impact force: ' + (g ?? 0).toFixed(2) + 'G', 'critical');
    fallCooldown = 10;
  } else if (!isFall && fallActive) {
    fallCooldown--;
    if (fallCooldown <= 0) {
      fallActive = false;
      valFall.textContent = 'Safe';
      valFall.style.color = '#4ade80';
      if (fallIcon) fallIcon.textContent = 'OK';
      statusFall.textContent = 'No incidents detected';
      cardFall.classList.remove('danger-mode');
      cardFall.style.borderTopColor = '';
    }
  } else if (!isFall) {
    valFall.textContent = 'Safe';
    valFall.style.color = '#4ade80';
    if (fallIcon) fallIcon.textContent = 'OK';
    statusFall.textContent = 'No incidents detected';
  }
}

// Dismiss fall overlay
window.dismissFall = function() {
  fallOverlay.classList.add('hidden');
  fallActive = false;
  fallCooldown = 0;
  cardFall.classList.remove('danger-mode');
  cardFall.style.borderTopColor = '';
  valFall.textContent = 'Safe';
  valFall.style.color = '#4ade80';
  if (fallIcon) fallIcon.textContent = 'OK';
  statusFall.textContent = 'No incidents detected';
};

// ── EMERGENCY SOS ALERT (3 BUTTON PRESSES) ──────────────────────────────────
let sosActive = false;
const sosOverlay = $('sosAlertOverlay');

function updateSos(isSos) {
  if (isSos && !sosActive) {
    sosActive = true;
    if (sosOverlay) sosOverlay.classList.remove('hidden');
    addAlert('🚨 EMERGENCY SOS: 3 Button Presses Confirmed — Calling +91 9994684450', 'critical');
    
    // Voice speech announcement
    if ('speechSynthesis' in window) {
      try {
        const utterance = new SpeechSynthesisUtterance('Emergency SOS alert triggered. Initiating emergency call to mobile number.');
        window.speechSynthesis.speak(utterance);
      } catch (e) {}
    }

    // Trigger WhatsApp / Backend Alert
    const motherName = localStorage.getItem('momcare_mother_name') || 'Mom';
    fetch('/api/alert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        alertMessage: '🚨 EMERGENCY BUTTON PRESSED (3 Clicks) — Immediate Assistance Requested for +91 9994684450',
        timestamp: Date.now(),
        motherName: motherName,
        recipientNumber: '919994684450'
      })
    }).catch(e => console.log('Alert dispatch error:', e));
  }
}

// Dismiss SOS overlay
window.dismissSos = function() {
  if (sosOverlay) sosOverlay.classList.add('hidden');
  sosActive = false;
};

// ── ECG CANVAS DRAWING ─────────────────────────────────────────────────────
function updateEcg(value) {
  ecgBuffer[ecgWriteHead % MAX_ECG_POINTS] = value;
  ecgWriteHead++;
  drawEcg();
}

function drawEcg() {
  const W = ecgCanvas.width;
  const H = ecgCanvas.height;
  ecgCtx.clearRect(0, 0, W, H);

  // Do not draw active waveform unless Bluetooth is connected
  if (!isBleConnected) return;

  const MIN = 0, MAX = 4095;   // Full ADC range — shows real signal even if leads-off
  const n = Math.min(ecgWriteHead, MAX_ECG_POINTS);
  if (n < 2) return;

  // Background
  ecgCtx.fillStyle = 'transparent';
  ecgCtx.fillRect(0, 0, W, H);

  // Glow trail
  const gradient = ecgCtx.createLinearGradient(0, 0, W, 0);
  gradient.addColorStop(0, 'rgba(6,182,212,0)');
  gradient.addColorStop(0.7, 'rgba(6,182,212,0.6)');
  gradient.addColorStop(1, 'rgba(6,182,212,1)');

  ecgCtx.beginPath();
  ecgCtx.strokeStyle = gradient;
  ecgCtx.lineWidth = 2.2;
  ecgCtx.shadowBlur = 14;
  ecgCtx.shadowColor = '#06B6D4';
  ecgCtx.lineJoin = 'round';
  ecgCtx.lineCap = 'round';

  for (let i = 0; i < n; i++) {
    const bufIdx = (ecgWriteHead - n + i) % MAX_ECG_POINTS;
    const val = ecgBuffer[(bufIdx + MAX_ECG_POINTS) % MAX_ECG_POINTS];
    const x = (i / (MAX_ECG_POINTS - 1)) * W;
    const y = H - ((val - MIN) / (MAX - MIN)) * (H - 20) - 10;
    if (i === 0) ecgCtx.moveTo(x, y);
    else ecgCtx.lineTo(x, y);
  }
  ecgCtx.stroke();

  // Draw scan head
  const headX = ((ecgWriteHead - 1) % MAX_ECG_POINTS / (MAX_ECG_POINTS - 1)) * W;
  ecgCtx.shadowBlur = 20;
  ecgCtx.strokeStyle = '#06B6D4';
  ecgCtx.lineWidth = 3;
  ecgCtx.beginPath();
  ecgCtx.moveTo(headX, 0);
  ecgCtx.lineTo(headX, H);
  ecgCtx.stroke();

  ecgCtx.shadowBlur = 0;
}

// ── LINE CHART RENDERER ─────────────────────────────────────────────────────
function drawLineChart(ctx, canvas, data, opts) {
  const W = canvas.width;
  const H = canvas.height;
  const PAD = { top: 14, right: 14, bottom: 24, left: 38 };
  const w = W - PAD.left - PAD.right;
  const h = H - PAD.top - PAD.bottom;

  ctx.clearRect(0, 0, W, H);
  if (!data || data.length < 2) return;

  const min = opts.min ?? Math.min(...data);
  const max = opts.max ?? Math.max(...data);
  const range = max - min || 1;

  const toX = i => PAD.left + (i / (data.length - 1)) * w;
  const toY = v => PAD.top + h - ((v - min) / range) * h;

  // Grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = PAD.top + (h / 4) * i;
    ctx.beginPath(); ctx.moveTo(PAD.left, y); ctx.lineTo(PAD.left + w, y); ctx.stroke();
    const labelVal = max - ((max - min) / 4) * i;
    ctx.fillStyle = 'rgba(139,163,199,0.6)';
    ctx.font = '9px Inter, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(labelVal.toFixed(1), PAD.left - 4, y + 3);
  }

  // Reference lines
  if (opts.referenceLines) {
    opts.referenceLines.forEach(ref => {
      const y = toY(ref.y);
      ctx.save();
      ctx.strokeStyle = ref.color;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(PAD.left, y); ctx.lineTo(PAD.left + w, y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    });
  }

  // Fill area
  const grad = ctx.createLinearGradient(0, PAD.top, 0, PAD.top + h);
  grad.addColorStop(0, opts.fill || 'rgba(244,63,110,0.2)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');

  ctx.beginPath();
  ctx.moveTo(toX(0), toY(data[0]));
  for (let i = 1; i < data.length; i++) ctx.lineTo(toX(i), toY(data[i]));
  ctx.lineTo(toX(data.length - 1), PAD.top + h);
  ctx.lineTo(PAD.left, PAD.top + h);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Line
  ctx.beginPath();
  ctx.strokeStyle = opts.color;
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.shadowBlur = 8;
  ctx.shadowColor = opts.color;
  ctx.moveTo(toX(0), toY(data[0]));
  for (let i = 1; i < data.length; i++) ctx.lineTo(toX(i), toY(data[i]));
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Latest dot
  const last = data[data.length - 1];
  ctx.beginPath();
  ctx.arc(toX(data.length - 1), toY(last), 4, 0, Math.PI * 2);
  ctx.fillStyle = opts.color;
  ctx.shadowBlur = 12; ctx.shadowColor = opts.color;
  ctx.fill();
  ctx.shadowBlur = 0;

  // Label
  ctx.fillStyle = 'rgba(139,163,199,0.5)';
  ctx.font = '9px Inter, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(opts.label, PAD.left, PAD.top + h + 16);
}

// ── BAR CHART RENDERER ──────────────────────────────────────────────────────
function drawBarChart(ctx, canvas, data, opts) {
  const W = canvas.width;
  const H = canvas.height;
  const PAD = { top: 14, right: 14, bottom: 24, left: 38 };
  const w = W - PAD.left - PAD.right;
  const h = H - PAD.top - PAD.bottom;

  ctx.clearRect(0, 0, W, H);
  if (!data || data.length < 1) return;

  const max = Math.max(...data, 100);
  const barW = Math.max(2, (w / data.length) - 2);

  data.forEach((val, i) => {
    const barH = (val / max) * h;
    const x = PAD.left + (i / data.length) * w;
    const y = PAD.top + h - barH;

    const alpha = val > 50 ? 1 : 0.3;
    ctx.fillStyle = opts.color || '#a78bfa';
    ctx.globalAlpha = alpha;
    ctx.shadowBlur = val > 100 ? 12 : 0;
    ctx.shadowColor = opts.color || '#a78bfa';
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, [2, 2, 0, 0]);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;

  // Label
  ctx.fillStyle = 'rgba(139,163,199,0.5)';
  ctx.font = '9px Inter, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Fetal Activity', PAD.left, PAD.top + h + 16);
}

// ── MOTION GAUGE ────────────────────────────────────────────────────────────
function drawMotionGauge(ctx, canvas, g) {
  const W = canvas.width;
  const H = canvas.height;
  const cx = W / 2, cy = H / 2;
  const R = (Math.min(W, H) / 2) - 6;

  ctx.clearRect(0, 0, W, H);

  // Background arc
  ctx.beginPath();
  ctx.arc(cx, cy, R, Math.PI * 0.75, Math.PI * 2.25);
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Value arc
  const fraction = Math.min(g / 4, 1);
  const startAngle = Math.PI * 0.75;
  const endAngle = startAngle + fraction * Math.PI * 1.5;
  const color = g > MOTION_FALL ? '#ff2d55' : g > 1.5 ? '#fbbf24' : '#2dd4bf';

  ctx.beginPath();
  ctx.arc(cx, cy, R, startAngle, endAngle);
  ctx.strokeStyle = color;
  ctx.lineWidth = 7;
  ctx.shadowBlur = 10; ctx.shadowColor = color;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Value text
  ctx.fillStyle = color;
  ctx.font = `bold 13px Inter, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(g.toFixed(1), cx, cy);
  ctx.font = '7px Inter, sans-serif';
  ctx.fillStyle = 'rgba(139,163,199,0.6)';
  ctx.fillText('G', cx, cy + 10);
}

// ── ALERT LOG ───────────────────────────────────────────────────────────────
const alertThrottle = {};

function addAlert(msg, severity = 'info') {
  // Throttle duplicate alerts (5s window)
  const key = msg.substring(0, 30);
  const now = Date.now();
  if (alertThrottle[key] && now - alertThrottle[key] < 5000) return;
  alertThrottle[key] = now;

  const empty = alertLog.querySelector('.alert-log-empty');
  if (empty) empty.remove();

  // Remove oldest alert entry if over limit (never remove the placeholder)
  const entries = alertLog.querySelectorAll('.alert-entry');
  if (entries.length >= MAX_ALERTS) {
    alertLog.removeChild(entries[entries.length - 1]);
  }
  alertCount = alertLog.querySelectorAll('.alert-entry').length;

  const timeString = new Date().toLocaleTimeString('en-IN');
  const entry = document.createElement('div');
  entry.className = `alert-entry severity-${severity}`;
  entry.innerHTML = `
    <div class="alert-entry-body">
      <div class="alert-entry-msg">${msg}</div>
      <div class="alert-entry-time">${timeString}</div>
      <div class="whatsapp-status" style="font-size: 10px; color: #8ba3c7; margin-top: 4px;"></div>
    </div>`;

  alertLog.insertBefore(entry, alertLog.firstChild);
  alertCount++;

  // ── Send to Backend for WhatsApp Notification ──
  const statusEl = entry.querySelector('.whatsapp-status');
  fetch('/api/alert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
      alertMessage: msg, 
      timestamp: now,
      motherName: appMotherName,
      recipientNumber: appEmergencyPhone
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && data.status === 'SENT' && !data.duplicate) {
      statusEl.innerHTML = `✓ WhatsApp Triggered to ${data.recipient}`;
      statusEl.style.color = '#4ade80';
    } else if (data.success && data.status === 'SKIPPED_NO_CREDENTIALS') {
      // Don't show anything for missing credentials (user request)
    } else if (data.duplicate) {
      // It's a duplicate on the backend side, do not show anything
    } else if (!data.success) {
      statusEl.innerHTML = `⚠️ WhatsApp Error: ${data.error}`;
      statusEl.style.color = '#fbbf24';
    }
  })
  .catch(err => {
    console.error('Failed to trigger WhatsApp:', err);
  });
}

window.clearAlerts = function() {
  alertLog.innerHTML = '<div class="alert-log-empty">No alerts yet. System monitoring...</div>';
  alertCount = 0;
  // Clear throttle cache so alerts can immediately re-appear after clearing
  Object.keys(alertThrottle).forEach(k => delete alertThrottle[k]);
};

// ── RESIZE HANDLER ──────────────────────────────────────────────────────────
function resizeCanvases() {
  [ecgCanvas, bpmCanvas, tempCanvas, motionCanvas, kickCanvas].forEach(c => {
    const parent = c.parentElement;
    const rect = parent.getBoundingClientRect();
    if (rect.width > 0) {
      c.width = rect.width;
    }
  });
}

const resizeObserver = new ResizeObserver(() => resizeCanvases());
document.querySelectorAll('.ecg-canvas-wrap, .bpm-panel, .temp-panel, .motion-panel, .kick-panel')
  .forEach(el => resizeObserver.observe(el));

// ── INITIAL STARTUP ─────────────────────────────────────────────────────────

// Draw empty charts on load
setTimeout(() => {
  resizeCanvases();
  drawLineChart(bpmCtx, bpmCanvas, [0,0,0,0,0], { color:'#E11D48', fill:'rgba(225,29,72,0.15)', label:'BPM', min:40, max:120 });
  drawLineChart(tempCtx, tempCanvas, [0,0,0,0,0], { color:'#F59E0B', fill:'rgba(245,158,11,0.15)', label:'°C', min:35, max:40 });
  drawLineChart(motionCtx, motionCanvas, [0,0,0,0,0], { color:'#06B6D4', fill:'rgba(6,182,212,0.15)', label:'G', min:0, max:4 });
  drawMotionGauge(gaugeCtx, motionGauge, 0);
}, 300);

// ── WEB BLUETOOTH INTEGRATION ───────────────────────────────────────────────
const btnConnectBLE = $('btnConnectBLE');

const UART_SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
const UART_TX_UUID      = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"; // ESP32 TX -> Browser RX

const MAX_LOCAL_HISTORY = 60;
const localHistory = {
  ecg: [], bpm: [], piezo: [], kicks: [], motion: [], temp: [], timestamps: []
};

let bleBuffer = "";

function parseBleLine(line) {
  try {
    const trimmed = line.trim();
    if (!trimmed.startsWith('ECG:')) return null;
    const parts = {};
    trimmed.split(',').forEach(segment => {
      const colonIdx = segment.indexOf(':');
      if (colonIdx > 0) {
        parts[segment.substring(0, colonIdx).trim()] = parseFloat(segment.substring(colonIdx + 1).trim());
      }
    });
    if (isNaN(parts['ECG'])) return null;

    let rawBpm = parts['Maternal_BPM'] ?? 0;
    const cleanBpm = (rawBpm > BPM_VALID_MIN && rawBpm <= BPM_VALID_MAX) ? rawBpm : 0;

    return {
      ecg:        parts['ECG']            ?? 0,
      bpm:        cleanBpm,
      piezo:      parts['Piezo_Force']    ?? 0,
      kicks:      parts['Kicks_Total']    ?? 0,
      motion:     parts['Motion_Total_G'] ?? 0,
      temp:       parts['Temp_C']         ?? 0,
      fallAlert:  parts['Fall_Alert'] === 1,
      sosCall:    parts['SOS_Call'] === 1,
      pressCount: parts['Press_Count']    ?? 0,
      mpuOK:      parts['MPU_OK'] !== 0,
      timestamp:  Date.now()
    };
  } catch { return null; }
}

function updateBleBannerState(connected) {
  const banner = $('bleStandbyBanner');
  if (banner) {
    banner.style.display = connected ? 'none' : 'flex';
  }
}

// ── MANUAL ALERT HANDLER ───────────────────────────────────────────────────
window.handleManualAlert = function() {
  updateSos(true);
};

if (btnConnectBLE) {
  btnConnectBLE.addEventListener('click', async () => {
    if (!navigator.bluetooth) {
      alert('Web Bluetooth is supported on Google Chrome, Microsoft Edge, and Opera.\n\nPlease open this dashboard in Google Chrome or Microsoft Edge.');
      return;
    }
    try {
      console.log('Requesting Bluetooth Device for MomCare...');
      let device;
      try {
        device = await navigator.bluetooth.requestDevice({
          filters: [
            { name: 'MomCare' },
            { namePrefix: 'MomCare' },
            { namePrefix: 'Mom' }
          ],
          optionalServices: [UART_SERVICE_UUID]
        });
      } catch (filterErr) {
        if (filterErr.name === 'NotFoundError') {
          console.log('Bluetooth picker was dismissed by the user.');
          return;
        }
        console.warn('Filter fallback to acceptAllDevices:', filterErr);
        device = await navigator.bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: [UART_SERVICE_UUID]
        });
      }

      setConnected('connecting');
      statusText.textContent = 'Connecting to MomCare...';

      const server = await device.gatt.connect();
      const service = await server.getPrimaryService(UART_SERVICE_UUID);
      const characteristic = await service.getCharacteristic(UART_TX_UUID);

      await characteristic.startNotifications();
      
      isBleConnected = true;
      updateBleBannerState(true);
      setConnected('connected');
      statusText.textContent = 'MomCare Connected (BLE)';
      btnConnectBLE.style.display = 'none'; // Hide button after successful connection

      // Update Live Dot to blue for BLE
      const liveDot = document.querySelector('#liveIndicator .live-dot');
      if (liveDot) { liveDot.style.background = '#3b82f6'; liveDot.style.boxShadow = `0 0 8px #3b82f6`; }
      if (sysConnMode) sysConnMode.textContent = 'Web Bluetooth (BLE)';

      device.addEventListener('gattserverdisconnected', () => {
        isBleConnected = false;
        updateBleBannerState(false);
        setConnected('error');
        statusText.textContent = 'BLE Disconnected (Standby)';
        btnConnectBLE.style.display = 'flex'; // Show button again

        // Reset all live values strictly to 0
        if (valBpm) valBpm.textContent = '0';
        if (statusBpm) { statusBpm.textContent = '0 BPM'; statusBpm.style.color = '#8ba3c7'; }
        if (valTemp) valTemp.textContent = '0.0';
        if (statusTemp) { statusTemp.textContent = '0.0 °C'; statusTemp.style.color = '#8ba3c7'; }
        if (tempBar) tempBar.style.width = '0%';
        if (valKicks) valKicks.textContent = '0';
        if (statusKicks) { statusKicks.textContent = '0 kicks'; statusKicks.style.color = '#8ba3c7'; }
        if (valMotion) valMotion.textContent = '0.00';
        if (statusMotion) { statusMotion.textContent = '0.00 G'; statusMotion.style.color = '#8ba3c7'; }
        if (valPiezo) valPiezo.textContent = '0';
        if (statusPiezo) { statusPiezo.textContent = '0 raw'; statusPiezo.style.color = '#8ba3c7'; }
        if (valFall) valFall.textContent = '0';
        if (statusFall) { statusFall.textContent = 'No incidents detected'; statusFall.style.color = '#8ba3c7'; }
        if (ecgBpmDisplay) ecgBpmDisplay.textContent = '0 BPM';
        if (motionGauge && gaugeCtx) drawMotionGauge(gaugeCtx, motionGauge, 0);
        ecgWriteHead = 0;
        ecgBuffer.fill(0);
        if (ecgCtx && ecgCanvas) ecgCtx.clearRect(0, 0, ecgCanvas.width, ecgCanvas.height);
      });

      characteristic.addEventListener('characteristicvaluechanged', (event) => {
        const value = event.target.value;
        const decoder = new TextDecoder('utf-8');
        bleBuffer += decoder.decode(value);
        
        let newlineIdx;
        while ((newlineIdx = bleBuffer.indexOf('\n')) !== -1) {
          const line = bleBuffer.substring(0, newlineIdx);
          bleBuffer = bleBuffer.substring(newlineIdx + 1);
          
          // Fix for CRLF if present
          const cleanLine = line.replace('\r', '');
          
          const data = parseBleLine(cleanLine);
          if (data) {
            dataCount++;
            const dpEl = $('sysDataPoints');
            if (dpEl) dpEl.textContent = dataCount.toLocaleString();
            
            // Build local history for charts
            ['ecg','bpm','piezo','kicks','motion','temp'].forEach(k => {
              localHistory[k].push(data[k]);
              if (localHistory[k].length > MAX_LOCAL_HISTORY) localHistory[k].shift();
            });
            localHistory.timestamps.push(data.timestamp);
            if (localHistory.timestamps.length > MAX_LOCAL_HISTORY) localHistory.timestamps.shift();
            
            // Feed into main UI renderer directly
            updateDashboard(data, localHistory);
          }
        }
      });
      
    } catch (error) {
      console.error('BLE Error:', error);
      if (error.name !== 'NotFoundError') {
        alert('Bluetooth Connection Notice:\n' + error.message + '\n\nPlease ensure Bluetooth is turned ON in Windows Settings (Win + I -> Bluetooth & devices -> Turn ON).');
      }
      if (!isBleConnected) {
        setConnected('error');
        statusText.textContent = 'BLE Disconnected';
      }
    }
  });
}
/* ══════════════════════════════════════════════════════════════════════════
   NEW FEATURES: Modals, History, Compare & AI Chat
   ══════════════════════════════════════════════════════════════════════════ */

window.currentVitals = null;
window.currentHistory = null;

// Hook into updateDashboard to capture the latest data globally for the AI/History
const originalUpdateDashboard = updateDashboard;
updateDashboard = function(data, hist) {
  window.currentVitals = data;
  window.currentHistory = hist;
  originalUpdateDashboard(data, hist);
  updateHistoryTable(data);
  updateAIEngine(data, hist);
};

// ── AI Engine Updater ──
function updateAIEngine(data, hist) {
  // Throttle AI processing to simulate Edge AI batching
  if (dataCount % 5 !== 0) return;

  if (!window.MomCareAI) return;

  // 1. Fetal Movement Analysis
  const fetal = window.MomCareAI.analyzeFetalMovement(hist);
  const fetalRiskEl = document.getElementById('aiFetalRisk');
  if (fetalRiskEl) {
    document.getElementById('aiFetalBaseline').textContent = fetal.baseline;
    document.getElementById('aiFetalDeviation').textContent = (fetal.deviation > 0 ? '+' : '') + fetal.deviation + '%';
    fetalRiskEl.textContent = fetal.riskLevel + ' RISK';
    fetalRiskEl.className = 'ai-risk-badge ' + fetal.riskLevel.toLowerCase();

    if (fetal.alert) {
       addAlert('AI Warning: Unexplained reduction in fetal movement detected.', 'critical');
    }
  }

  // 2. Health Trend Prediction
  const trend = window.MomCareAI.predictHealthTrend(hist);
  const trendScoreEl = document.getElementById('aiTrendScore');
  if (trendScoreEl) {
    const trendCatEl = document.getElementById('aiTrendCategory');
    const trendExpEl = document.getElementById('aiTrendExplanations');
    
    trendScoreEl.textContent = trend.score;
    trendCatEl.textContent = trend.category + ' RISK';
    
    // Set gauge color
    let color = '#4ade80';
    if (trend.category === 'YELLOW') color = '#fbbf24';
    if (trend.category === 'ORANGE') color = '#f97316';
    if (trend.category === 'RED') color = '#ef4444';
    trendScoreEl.style.color = color;
    trendCatEl.style.color = color;

    trendExpEl.innerHTML = trend.explanations.map(e => `<li>${e}</li>`).join('');

    // 3. Nutrition Recommendation
    const medAdherenceEl = document.getElementById('medAdherence');
    const medTaken = medAdherenceEl ? medAdherenceEl.checked : true;
    
    const profile = {
      anemiaRisk: 'low',
      bpTrend: trend.score > 50 ? 'high' : 'normal',
      bmi: 'normal'
    };
    const nutrition = window.MomCareAI.generateNutritionPlan(data, profile);
    
    document.getElementById('aiNutritionFocus').textContent = nutrition.focus;
    
    let recsHTML = nutrition.recommendations.map(r => `<li>✅ ${r}</li>`).join('');
    if (nutrition.limits && nutrition.limits.length > 0) {
       recsHTML += nutrition.limits.map(l => `<li>⛔ Limit: ${l}</li>`).join('');
    }
    if (!medTaken) {
       recsHTML = `<li style="color:var(--accent-amber);font-weight:600;">⚠️ Reminder: Please take your prescribed prenatal vitamins today.</li>` + recsHTML;
    }
    
    document.getElementById('aiNutritionRecs').innerHTML = recsHTML;
    document.getElementById('aiNutritionHydration').textContent = nutrition.hydration;

    // Update Doctor Dashboard Summary
    const docSummary = document.getElementById('doctorSummaryContent');
    if (docSummary) {
        docSummary.innerHTML = `
          <p><strong>Overall AI Risk Score:</strong> <span style="color:${color}">${trend.score} / 100 (${trend.category})</span></p>
          <p><strong>Fetal Activity:</strong> Baseline ${fetal.baseline}, Deviation ${fetal.deviation}%</p>
          <p><strong>Trends:</strong></p>
          <ul style="margin-top:5px;">${trend.explanations.map(e => `<li>${e}</li>`).join('')}</ul>
          <p style="margin-top:10px;"><strong>Medicine Adherence:</strong> <span style="color:${medTaken?'#4ade80':'#f43f6e'}">${medTaken ? 'Confirmed' : 'Missed'}</span></p>
          <hr style="border-color: rgba(255,255,255,0.1); margin: 15px 0;">
          <p><em>Edge AI model outputs are based on latest sensor telemetry. Not a clinical diagnosis.</em></p>
        `;
    }
  }
};

// ── Modals ──
window.openModal = function(id) {
  document.getElementById(id).classList.remove('hidden');
  if (id === 'compareModal') {
    renderCompareChart();
  }
};
window.closeModal = function(id) {
  document.getElementById(id).classList.add('hidden');
};

// ── History Table ──
const historyTableBody = document.getElementById('historyTableBody');
function updateHistoryTable(data) {
  if (!historyTableBody) return;
  const time = new Date(data.timestamp || Date.now()).toLocaleTimeString('en-IN');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td>${time}</td>
    <td>${data.bpm > 0 ? data.bpm.toFixed(0) : '--'}</td>
    <td>${data.temp > 30 ? data.temp.toFixed(1) : '--'}</td>
    <td>${(data.motion || 0).toFixed(2)}</td>
    <td>${data.kicks || 0}</td>
  `;
  historyTableBody.insertBefore(tr, historyTableBody.firstChild);
  if (historyTableBody.children.length > 50) {
    historyTableBody.removeChild(historyTableBody.lastChild);
  }
}

// ── Compare Chart ──
function renderCompareChart() {
  const canvas = document.getElementById('compareChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  
  // Update text based on current vitals if available
  if (window.currentVitals) {
     const kThis = document.getElementById('compKicksThis');
     if (kThis) kThis.textContent = window.currentVitals.kicks;
  }
  
  ctx.clearRect(0,0,canvas.width, canvas.height);
  // Draw a simple simulated bar chart for Comparison
  const labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
  const dataThis = [65, 68, 70, window.currentVitals && window.currentVitals.bpm > 0 ? window.currentVitals.bpm : 74];
  const dataLast = [62, 64, 66, 68];
  
  const w = canvas.width, h = canvas.height;
  const pad = 30;
  const max = 100;
  
  ctx.fillStyle = 'rgba(255,255,255,0.02)';
  ctx.fillRect(pad, pad, w - pad*2, h - pad*2);
  
  const barW = 24;
  const gap = 100;
  const startX = pad + 60;
  
  for(let i=0; i<4; i++) {
    const x = startX + i * gap;
    
    // Last month (white/grey)
    const hLast = (dataLast[i]/max) * (h - pad*2);
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.fillRect(x, h - pad - hLast, barW, hLast);
    
    // This month (pink)
    const hThis = (dataThis[i]/max) * (h - pad*2);
    ctx.fillStyle = '#f43f6e';
    ctx.fillRect(x + barW + 5, h - pad - hThis, barW, hThis);
    
    ctx.fillStyle = '#8ba3c7';
    ctx.font = '12px Inter';
    ctx.textAlign = 'center';
    ctx.fillText(labels[i], x + barW, h - 10);
  }
}

// ── AI Chatbot (Groq-powered) ────────────────────────────────────────────────
const aiChatPanel  = document.getElementById('aiChatPanel');
const aiChatInput  = document.getElementById('aiChatInput');
const aiChatHistory= document.getElementById('aiChatHistory');

let isChatLoading = false;

window.toggleAiChat = function() {
  if (aiChatPanel.classList.contains('hidden')) {
    aiChatPanel.classList.remove('hidden');
    aiChatInput.focus();
  } else {
    aiChatPanel.classList.add('hidden');
  }
};

window.handleAiChatEnter = function(e) {
  if (e.key === 'Enter') sendAiMessage();
};

window.sendAiMessage = async function() {
  const text = aiChatInput.value.trim();
  if (!text || isChatLoading) return;

  addChatMessage(text, 'user');
  aiChatInput.value = '';

  // Show a typing indicator
  const typingEl = addChatMessage('Thinking...', 'ai typing');
  isChatLoading = true;

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: text,
        vitals: window.currentVitals || null,
      }),
    });

    const data = await res.json();
    typingEl.remove();

    if (data.error) {
      addChatMessage('Error: ' + data.error, 'ai error-msg');
    } else {
      addChatMessage(data.reply, 'ai');
    }
  } catch (err) {
    typingEl.remove();
    addChatMessage('Could not reach the AI service. Is the server running?', 'ai error-msg');
  } finally {
    isChatLoading = false;
  }
};

function addChatMessage(text, classList) {
  const div = document.createElement('div');
  div.className = 'chat-msg ' + classList;
  div.textContent = text;
  aiChatHistory.appendChild(div);
  aiChatHistory.scrollTop = aiChatHistory.scrollHeight;
  return div;
}

// ── Manual Alert Logic ────────────────────────────────────────────────────────
let manualAlertState = 0; // 0 = default, 1 = ready, 2 = triggered
let manualAlertElement = null; 

window.handleManualAlert = function() {
  const btn = document.getElementById('manualAlertBtn');
  if (manualAlertState === 0) {
    manualAlertState = 1;
    btn.textContent = 'Alert Ready (Press again)';
    btn.style.background = '#f59e0b';
  } else if (manualAlertState === 1) {
    manualAlertState = 2;
    btn.textContent = 'Delete Manual Alert';
    btn.style.background = '#ef4444';
    manualAlertElement = addAlertWithDelete('MANUAL ALERT TRIGGERED', 'critical');
  } else if (manualAlertState === 2) {
    manualAlertState = 0;
    btn.textContent = 'Manual Alert';
    btn.style.background = 'var(--accent-rose)';
    if (manualAlertElement && manualAlertElement.parentNode) {
       manualAlertElement.parentNode.removeChild(manualAlertElement);
    }
    manualAlertElement = null;
  }
};

function addAlertWithDelete(msg, severity) {
  const empty = alertLog.querySelector('.alert-log-empty');
  if (empty) empty.remove();
  
  const timeString = new Date().toLocaleTimeString('en-IN');
  const now = Date.now();
  const entry = document.createElement('div');
  entry.className = `alert-entry severity-${severity}`;
  entry.innerHTML = `
    <div class="alert-entry-body">
      <div class="alert-entry-msg">${msg}</div>
      <div class="alert-entry-time">${timeString}</div>
      <div class="whatsapp-status" style="font-size: 10px; color: #8ba3c7; margin-top: 4px;"></div>
    </div>`;

  alertLog.insertBefore(entry, alertLog.firstChild);
  alertCount++;

  const statusEl = entry.querySelector('.whatsapp-status');
  fetch('/api/alert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
      alertMessage: msg, 
      timestamp: now,
      motherName: appMotherName,
      recipientNumber: appEmergencyPhone
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && data.status === 'SENT' && !data.duplicate) {
      statusEl.innerHTML = `✓ WhatsApp Triggered to ${data.recipient}`;
      statusEl.style.color = '#4ade80';
    } else if (data.success && data.status === 'SKIPPED_NO_CREDENTIALS') {
      // Don't show anything for missing credentials
    } else if (data.duplicate) {
      // Duplicate
    } else if (!data.success) {
      statusEl.innerHTML = `⚠️ WhatsApp Error: ${data.error}`;
      statusEl.style.color = '#fbbf24';
    }
  })
  .catch(err => {
    console.error('Failed to trigger WhatsApp:', err);
  });

  return entry;
}

window.testWhatsAppAlert = function() {
  const testMsg = `TEST ALERT: System test initiated at ${new Date().toLocaleTimeString()}`;
  addAlert(testMsg, 'critical');
};

// ── Login Flow ─────────────────────────────────────────────────────────────
let appMotherName = '';
let appMotherPhone = '';
let appEmergencyName = '';
let appEmergencyPhone = '';

window.nextLoginStep = function() {
  const mName = document.getElementById('motherNameInput').value.trim();
  const mPhone = document.getElementById('motherPhoneInput').value.trim();
  if (!mName || !mPhone) {
    alert('Please enter both Mother\'s Name and Phone Number.');
    return;
  }
  appMotherName = mName;
  appMotherPhone = mPhone;

  const headerPatient = document.getElementById('headerPatientName');
  if (headerPatient) headerPatient.innerText = `Patient: ${appMotherName}`;
  
  document.getElementById('loginStep1').classList.add('hidden');
  document.getElementById('loginStep2').classList.remove('hidden');
};

window.finishLogin = function() {
  const eName = document.getElementById('contactNameInput').value.trim();
  const ePhone = document.getElementById('contactPhoneInput').value.trim();
  if (!eName || !ePhone) {
    alert('Please enter both Emergency Contact Name and Phone Number.');
    return;
  }
  appEmergencyName = eName;
  appEmergencyPhone = ePhone;

  document.getElementById('loginOverlay').classList.add('hidden');
};
